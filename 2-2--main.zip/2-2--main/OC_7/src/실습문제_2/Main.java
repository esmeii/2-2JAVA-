package �ǽ�����_2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		ArrayList<Character> ac = new ArrayList<Character>();
		char inputGrade,sumGrade; 
		double grade =0;
		
		
		System.out.println("6���� ������ �Է�>>");
		for(int i = 0;i<6;i++) {
			inputGrade =s.next().charAt(0);
			ac.add(inputGrade);
		}
		for(int i =0;i<ac.size();i++) {
			sumGrade = ac.get(i);
			switch(sumGrade) {
			case 'A':
			case 'a': grade += 4.0; break;
			case 'B': 
			case 'b': grade += 3.0; break;
			case 'C': grade += 2.0; break;
			case 'D': grade += 1.0; break;
			case 'F': grade += 0; break;
			}
		}
		System.out.println(grade/ac.size());
		s.close();
	}

}
