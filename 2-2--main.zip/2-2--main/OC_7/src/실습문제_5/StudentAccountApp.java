package �ǽ�����_5;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

class Student{
	private String name,major;
	private int id;
	private double grade;
	public Student(String name,String major,int id,double grade) {
		this.grade = grade;this.id=id;this.major=major;this.setName(name);
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getGrade() {
		return grade;
	}
	public void setGrade(double grade) {
		this.grade = grade;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void findByName(String searchName) {
		if(searchName.equals(name)) {
			System.out.print(name);
			System.out.print(" "+major);
			System.out.print(" " + id);
			System.out.println(" "+grade);
		}
	}
}
public class StudentAccountApp {
	public static void main(String[] args) {
		Student[] student = new Student[4];
		Scanner s = new Scanner(System.in);
		ArrayList<Student> students = new ArrayList<Student>();
		String name;String major;
		int id;
		Double grade;
		
		System.out.println("�л� �̸�,�а�,�й�,������� �Է��ϼ���.");
		for(int i=0;i<student.length;i++) {
			System.out.print(">> ");
			String input = s.nextLine(); 
			//StringTokenizer ����ϱ�
			StringTokenizer st = new StringTokenizer(input,",");
			name=st.nextToken().trim();
			major=st.nextToken().trim();
			id=Integer.parseInt(st.nextToken().trim());
			grade=Double.parseDouble(st.nextToken().trim());
			student[i] = new Student(name,major,id,grade);
			students.add(student[i]);
		}
		for(int i =0;i<students.size();i++) {
			System.out.println("------------------");
			Student stu = students.get(i);
			System.out.println("�̸�:"+stu.getName());
			System.out.println("�а�:"+stu.getMajor());
			System.out.println("�й�:"+stu.getId());
			System.out.println("�������:"+stu.getGrade());
		}
		System.out.println("-------------------");
		while(true) {
			System.out.println("�л��̸�>>");
			name = s.nextLine();
			if(name.equals("�׸�")) break;
			for(int i=0;i<students.size();i++) {
				Student s1= students.get(i);
				s1.findByName(name);
			}
		}
	}
}
