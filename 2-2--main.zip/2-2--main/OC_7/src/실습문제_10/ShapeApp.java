package �ǽ�����_10;

public class ShapeApp {

	public ShapeApp() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
