package �ǽ�����_3;

import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		HashMap<String,Integer> nations = new HashMap<String,Integer>();
		Scanner s = new Scanner(System.in);
		String inputCountry,search; 
		int inputPop;
		while(true) {
			System.out.print("���� �̸�, �α�>>");
			inputCountry=s.next();
				if(inputCountry.equals("�׸�")) break;
			inputPop = s.nextInt();
			nations.put(inputCountry, inputPop);
		}
		s.nextLine();
		while(true) {
			System.out.println("�α� �˻�");
			search = s.nextLine();
			if(search.equals("�׸�")) break;
			if(nations.containsKey(search)) 
				System.out.println(search+"�� �α��� "+nations.get(search));
			else System.out.println(search+"����� �����ϴ�.");
		}
	
	}

}
