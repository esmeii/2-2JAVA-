package �ǽ�����_1;
import java.util.Scanner;
import java.util.Vector;

public class Main {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = 0;
		Vector<Integer> v= new Vector<Integer>();
		int big = 0;
		
		System.out.print("����>>");
		while(true) {
			n = s.nextInt();
			if(n == -1) break;
			v.add(n);
			for(int i = 0;i<v.size();i++) {
				big =(v.get(i)>n)?v.get(i):n;
			}
			
		}
		System.out.println(big);
		s.close();
	}

}
