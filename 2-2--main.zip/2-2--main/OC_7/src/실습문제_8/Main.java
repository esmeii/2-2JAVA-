package �ǽ�����_8;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		HashMap<String,Integer> manageAccount = new HashMap<String,Integer>();
		System.out.println("**����Ʈ ���� ���α׷��Դϴ�.**");
		Scanner s = new Scanner(System.in);
		while(true) {
		System.out.print("�̸��� ����Ʈ �Է�>>");
		String name = s.next();
		int score = s.nextInt();
		if(manageAccount.containsKey(name)) {
			manageAccount.put(name,manageAccount.get(name)+score);
		}
		if(manageAccount.get(name) == null) {
			manageAccount.put(name, score);
		}
		Set<String> accountName = manageAccount.keySet();
		Iterator<String> it = accountName.iterator();
		while(it.hasNext()) {
			String person = it.next();
			int sum = manageAccount.get(person);
			System.out.print("("+person+sum+")");			
			}
		System.out.println();
		}
		
	}

}
