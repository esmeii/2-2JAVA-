package �ǽ�_6;

import java.util.Scanner;



public class CircleManager {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Circle c[] = new Circle[3];
		for(int i = 0;i<c.length;i++) {
		System.out.print("x,y,radius >>");
		double x = s.nextDouble();
		double y = s.nextDouble();
		int radius = s.nextInt();
		
		 c[i] = new Circle(x,y,radius);
		}
		Circle temp = new Circle(0,0,1);
		for(int i =0;i<c.length;i++) {
			if(temp.getRadius() <= c[i].getRadius()) {
				temp.setRadius(c[i].getRadius()); //ū ���� ���� ����
				temp.setX(c[i].getX());
				temp.setY(c[i].getY());
			}
		}
		System.out.print("���� ū ���� ");temp.show();
		
	}

}
