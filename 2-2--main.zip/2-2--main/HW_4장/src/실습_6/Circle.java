package �ǽ�_6;

public class Circle {
	private double x,y;
	private int radius;
	public Circle(double x, double y, int radius) {
		this.x = x; this.y = y; this.radius=radius;
	}
	public void show() {
		System.out.println("("+x+","+y+")"+radius);
	}
	public double big() {
		return radius*radius*3.14;
	}
	public int getRadius() {
		
		return this.radius;
	}
	public void setRadius(int r) {
		this.radius =r;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
}
