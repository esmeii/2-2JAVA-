package �ǽ�_3;

public class Song {
	String title;
	String artist;
	int year;
	String country;
	public Song() {
		
	}
	public Song(String title, String artist, int year, String country) {
		this.artist = artist;
		this.country = country;
		this.title = title;
		this.year = year;
	}
	public void show() {
		System.out.println(this.artist+this.country+this.title+this.year);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Song abba = new Song("DancingQueen","ABBA",1978,"������");
		abba.show();
	}

}
