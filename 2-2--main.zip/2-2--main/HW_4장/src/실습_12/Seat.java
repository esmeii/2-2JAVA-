package �ǽ�_12;

public class Seat {
	
}
