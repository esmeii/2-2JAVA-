package �ǽ�_12;

import java.util.Scanner;

public class SeatApp {
	public static final int MAX_Y=3;
	public static final int MAX_X=10;
	private Scanner s;
	private String map[][]=new String[MAX_Y][MAX_X];

	public SeatApp() { //constructor
		for(int i =0;i<MAX_Y;i++)
			for(int j =0;j<MAX_X;j++)
				map[i][j] ="---"; //���� �ʱ�ȭ
		s = new Scanner(System.in);
	}
	public void run() {
		System.out.println("��ǰ�ܼ�ƮȦ ���� �ý����Դϴ�.");
		
		while(true) {
		System.out.print("����:1, ��ȸ:2, ���:3, ������:4>>");
		int choice = s.nextInt();
		switch(choice) {
		case 1: reserv(); break;
		case 2: show(); break;
		case 3: cancel(); break;
		case 4: break;
		default: System.out.println("wrong input");
		}
		 if(choice == 4) break;
		}
	}
	public void cancel() {
		System.out.print("�¼� S:1, A:2, B:3");
		int in = s.nextInt();
		switch(in) {
		case 1://s�� ���ֱ�
			System.out.print("S>>");
			for(int i=0;i<map[1].length;i++)
				System.out.print(map[0][i]+" ");
			break;
		case 2: //A�� ���ֱ�
			System.out.print("A>>");
			for(int i=0;i<map[2].length;i++)
				System.out.print(map[1][i]+" ");
			break;
		case 3: //b�� ���ֱ�
			System.out.print("B>>");
			for(int i=0;i<map[3].length;i++)
				System.out.print(map[2][i]+" ");
			break;
		}
		System.out.println();
		System.out.print("�̸�>>");
		String cName = s.next();
		for(int i =0;i<MAX_Y;i++)
			for(int j =0;j<MAX_X;j++)
				if(cName.equals(map[i][j])) {
					map[i][j] = "--- ";
				}
	
	}
	public void show() {
		for(int i =0;i<MAX_Y;i++) {
			for(int j =0;j<MAX_X;j++) {
				System.out.print(map[i][j]+" ");
			}
		System.out.println();
		}
		System.out.println("��ȸ �Ϸ�");
	}
	public void reserv() {
		String name;
		int num;
		System.out.print("�¼����� S(1) A(2) B(3)>>");
		int sChoice = s.nextInt();
		switch(sChoice) {
		case 1://s��
			System.out.print("S>>");
			for(int i=0;i<map[1].length;i++)
				System.out.print(map[0][i]+" ");
			System.out.println();
			System.out.print("�̸�>>");
			name = s.next();
			System.out.print("��ȣ>>");
			num  = s.nextInt();
			map[0][num-1] = name;
			break;
		case 2: //A�� ���ֱ�
			System.out.print("A>>");
			for(int i=0;i<map[2].length;i++)
				System.out.print(map[1][i]+" ");
			System.out.println();
			System.out.print("�̸�>>");
			 name = s.next();
			System.out.print("��ȣ>>");
			num  = s.nextInt();
			map[1][num-1] = name;
			break;
		case 3: //b�� ���ֱ�
			System.out.print("B>>");
			for(int i=0;i<map[3].length;i++)
				System.out.print(map[2][i]+" ");
			System.out.println();
			System.out.print("�̸�>>");
			name = s.next();
			System.out.print("��ȣ>>");
			num  = s.nextInt();
			map[2][num-1] = name;
			break;
		}
	}
	public static void main(String[] args) {
		SeatApp seat = new SeatApp();
		seat.run();
	}

}
