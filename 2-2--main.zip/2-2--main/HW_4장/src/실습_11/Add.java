package �ǽ�_11;

public class Add extends Calc{

	public Add() {
		
	}

	@Override
	public int calculate() {
		
		return a+b;
	}

}
