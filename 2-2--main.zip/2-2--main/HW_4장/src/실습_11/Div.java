package �ǽ�_11;

public class Div extends Calc{

	public Div() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int calculate() {
		// TODO Auto-generated method stub
		return a/b;
	}

}
