package �ǽ�_11;

public class Mul extends Calc{

	public Mul() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int calculate() {
		// TODO Auto-generated method stub
		return a*b;
	}

}
