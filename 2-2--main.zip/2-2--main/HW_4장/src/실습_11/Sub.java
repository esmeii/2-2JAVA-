package �ǽ�_11;

public class Sub extends Calc{

	public Sub() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int calculate() {
		// TODO Auto-generated method stub
		return a-b;
	}

}
