package �ǽ�_11;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Calc cc = null;
		System.out.print("�� ������ �����ڸ� �Է��ϼ���>> ");
		int a= s.nextInt();
		int b = s.nextInt();
		char c= s.next().charAt(0);
		
		switch(c) {
		case '+' : cc =new Add(); cc.setValue(a, b); break;
		case '-' : cc= new Sub(); cc.setValue(a, b); break;
		case '/' : cc = new Div(); cc.setValue(a, b); break;
		case '*' : cc= new Mul(); cc.setValue(a, b); break;
		default: System.out.println("error");
		}
		if(b ==0 && c == '/') {
			System.out.println("0���δ� ���� �� �����ϴ�.");
		}
		else System.out.println(cc.calculate());
	}

}
