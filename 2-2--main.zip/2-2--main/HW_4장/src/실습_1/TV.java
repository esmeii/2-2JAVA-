package �ǽ�_1;

public class TV {
	String name;
	int year;
	int inch;
	TV(String name, int year, int inch){
		this.name = name; this.year = year; this.inch = inch;
	}//constructor
	public void show() {
		System.out.println(this.name+"���� ���� "+this.year+"��"+this.inch+"��ġ TV");
	}
	public static void main(String [] args) {
		TV tv = new TV("LG",2017,32);
		tv.show();
	}

}
