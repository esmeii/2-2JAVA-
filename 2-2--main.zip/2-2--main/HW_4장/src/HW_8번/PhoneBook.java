package HW_8��;

public class PhoneBook {
	public static void main(String[] args) {
		Phone phone = new Phone();
		phone.setArray();
		phone.getInfo();
		phone.searchInfo();
	}
}
