package �ǽ�_8;

public class Phone {
	String name;
	String tel;
	public Phone(String name, String tel) {
		this.name=name; this.tel=tel;
	}
	

}
