package �ǽ�_8;

import java.util.Scanner;

public class PhoneBook {
	Scanner s;
	Phone [] p;
	public PhoneBook() {
		s= new Scanner(System.in);
	}
	public void run() {
		boolean si = false;
		System.out.print("�ο��� >>");
		int num = s.nextInt();
		p = new Phone[num];
		for(int i=0;i<p.length;i++) {
			System.out.print("�̸��� ��ȭ��ȣ>> ");
			String name = s.next();
			String phone = s.next();
			s.nextLine();
			p[i] = new Phone(name,phone);
		}System.out.println("����Ǿ����ϴ�...");
		for(;;) {
			System.out.print("�˻��� �̸� >> ");
			String search = s.nextLine();
			if(search.equals("�׸�"))break;
			for(int i = 0;i<p.length;i++) {
				if(p[i].name.equals(search)) {
					si = true;
					System.out.println(search+"�� ��ȣ�� "+p[i].tel+"�Դϴ�.");
				}
			}
			if(si == false) System.out.println(search+"�� �����ϴ�.");
			
		}
	}
	public static void main(String[] args) {
		PhoneBook pb = new PhoneBook();
		pb.run();

	}

}
