package �ǽ�_5;

public class Circle {
	private double x,y;
	private int radius;
	
	public Circle(double x, double y, int radius) {
		this.setRadius(radius); this.setX(x); this.y=y;
	}
	public void show() {
		System.out.println("("+this.getX()+","+this.y+")"+this.getRadius());
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public int getRadius() {
		return radius;
	}
	public void setRadius(int radius) {
		this.radius = radius;
	}
	public void setY(double nextInt) {
		// TODO Auto-generated method stub
		this.y = nextInt;
	}
}
