package �ǽ�_5;

import java.util.Scanner;

public class CircleManager {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Circle c [] = new Circle[3];
		for(int i =0;i<c.length;i++) {
			System.out.print("x,y,radius >>");
			double x = s.nextDouble();
			double y = s.nextDouble();
			int r = s.nextInt();
			
			c[i] = new Circle(x,y,r);
		}//for end
		for(int i = 0;i<c.length;i++) {
			c[i].show();
		}
		s.close();
	}

}
