package �ǽ�_9;
class ArrayUtil {
	public static int [] concat(int [] a, int [] b) {
		int [] n = new int[a.length+b.length];
		
		for(int i =0;i<a.length;i++) {
			n[i] = a[i];
		}
		for(int j = 0;j<b.length;j++) {
			int index = a.length + j;//a ������ ����Ŵ
			n[index] = b[j];
		}
		return n;
	}
	public static void print(int[] a) {
		for(int i =0;i<a.length;i++)
			System.out.print(a[i]);
	}
public static class StaticEx{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] ar1 = {1,3,5,7};
		int [] ar2 = {2,4,6,8};
		int [] ar3 = ArrayUtil.concat(ar1, ar2);
		ArrayUtil.print(ar3);
	}
}
}
