package oc_10;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

public class GameFrame extends JFrame{
	public GameFrame() {
		super("Open Challenge_10");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setContentPane(new GamePanel());
		
		setSize(500,200);
		setVisible(true);
		getContentPane().setFocusable(true);
		getContentPane().requestFocus();
	}
	class GamePanel extends JPanel{
		private JLabel [] label = new JLabel [5];
		private JLabel result = new JLabel("�����մϴ�.");
		
		public GamePanel() {
			setLayout(null);
			for(int i =0 ;i<label.length;i++) {
				label[i] = new JLabel("0");
				label[i].setSize(60,30);
				label[i].setLocation(30+80*i,50);
				label[i].setHorizontalAlignment(JLabel.CENTER);
				label[i].setOpaque(true);
				label[i].setBackground(Color.magenta);
				label[i].setForeground(Color.yellow);
				label[i].setFont(new Font("Tahoma",Font.ITALIC,30));
				add(label[i]);
			}
			result.setSize(550,30);
			result.setLocation(100,120);
			result.setFont(new Font("�ü�",Font.BOLD,20));
			add(result);
			
			addKeyListener(new KeyAdapter() {
				public void keyPressed(KeyEvent e) {
					if(e.getKeyChar() == '\n') {
						int x1 =(int)(Math.random()*5);
						label[0].setText(Integer.toString(x1));
						int x2 =(int)(Math.random()*5);
						label[1].setText(Integer.toString(x2));
						int x3 =(int)(Math.random()*5);
						label[2].setText(Integer.toString(x3));
						
						
						int x4 =(int)(Math.random()*5);
						label[3].setText(Integer.toString(x4));
						int x5 =(int)(Math.random()*5);
						label[4].setText(Integer.toString(x5));
						if(x1 == x2 &&x2 == x3 &&x3 == x4 && x4==x5)
							result.setText("�����մϴ�.");
						else
							result.setText("�ƽ�����.");
					}
				}
			});
			
			addMouseListener(new MouseAdapter() {
				public void mouseClicked(MouseEvent e) {
					Component c = (Component)e.getSource();
					c.requestFocus();
				}
			});
		}
}

	static public void main(String[] arg) {
		new GameFrame();
	}
}
	
