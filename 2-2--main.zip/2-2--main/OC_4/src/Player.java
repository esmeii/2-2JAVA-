
public class Player {
	private String name;
	private String challengWord;
	private String prevWord = "�ƹ���";
	public Player() {
	}
	public Player(String name) {
		this.name = name;
	}
	public void getWordFromUser(String word) {
		challengWord = word;
	}
	public boolean checkSuccess() {
		int lastIndex = prevWord.length()-1;
		char lastChar = prevWord.charAt(lastIndex);
		char firstChar = challengWord.charAt(0);
		if(lastChar != firstChar) return false;
		else {
			prevWord = challengWord;
			return true;
		}
	}
	public String getName() {
		return name;
	}

}
