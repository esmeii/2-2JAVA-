import java.util.Scanner;

public class WordGameApp {
	Player[] p;
	Scanner s;
	int count;
	String input;
	public WordGameApp() {
	}
	public void run() {
		count =0;
		s = new Scanner(System.in);
		int playerNum = s.nextInt();
		Player[] players = new Player[playerNum];
		for(int i =0;i<playerNum;i++) {
			System.out.print("�������� �̸�>>");
			p[i] = new Player(s.nextLine());
		}
		System.out.println("�����ϴ� �ܾ�� �ƹ����Դϴ�.");
		while(true) {
			System.out.print(players[count].getName()+">>");
			players[count].getWordFromUser(s.nextLine());
			if(players[count].checkSuccess()) {
				count++;
				if(count>=playerNum) count = 0;
			}
			else {
				System.out.println(players[count].getName()+"�� �����ϴ�.");
				break;
			}
		}
	}
	public static void main(String[] args) {
		WordGameApp wga = new WordGameApp();
		wga.run();
	}

}
