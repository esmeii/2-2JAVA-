
public class Oval implements Shape {
	private int r,rr;
	private String color;
	public Oval(int r,int rr, String color) {
		this.r = r;
		this.color=color;
		this.rr= rr;
	}
	@Override
	public void draw() {System.out.println(r+"x"+rr+"�� �����ϴ� Ÿ���Դϴ�.");}

	@Override
	public double getArea() {
		double a = r/2;
		double b = rr/2;
		return a*b*PI;}
	
	@Override
	public double getRound() {
		int s = r/2; int ss=  rr/2;
		double temp = 0.5*s*s + ss*ss*0.5; //1/2 == 0.5
		double temp2 = Math.pow(temp, 0.5); 
		return 2*PI*temp2;
		}

	@Override
	public String getColor() {return "������ "+color;}

}
