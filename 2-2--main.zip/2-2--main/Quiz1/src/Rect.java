public class Rect implements Shape {
	private int width,height;
	private String color;
	public Rect(int width, int height, String color) {
		this.width = width; 
		this.height = height;
		this.color = color;
	}
	@Override
	public void draw() {
		System.out.println(width+"x"+height+"ũ���� �簢���Դϴ�.");
	}
	@Override
	public double getArea() {return width*height;}
	@Override
	public double getRound() {return 2*(height+width);	}
	@Override
	public String getColor() {return "������ "+color;	}

}
