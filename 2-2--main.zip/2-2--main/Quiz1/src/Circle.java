
public class Circle implements Shape {
	private int r;
	private String color;
	public Circle(int r,String color) {
		this.r =r; this.color=color;
	}
	@Override
	public void draw() {System.out.println("�������� "+r+"�� ���Դϴ�.");}

	@Override
	public double getArea() {return PI*r*r;}

	@Override
	public double getRound() {return 2*PI*r;}

	@Override
	public String getColor() {return "������ "+color;}

}
