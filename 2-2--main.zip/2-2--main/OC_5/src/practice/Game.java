package practice;

public class Game {
	public static final int MAX_X = 20;
	public static final int MAX_Y = 10;
	private char[][] map = new char[MAX_X][MAX_Y];
	private GameObject[] g;
	int state;
	public Game() {
		g = new GameObject[2]; //0,1
		for(int i =0;i<MAX_Y;i++)
			for(int j =0;j<MAX_X;j++)
				map[j][i] = '-';
		g[0] = new Bear(0,0,1);
		g[1] = new Fish(6,9,2);
		state = 0;
	}

	public static void main(String[] args) {
		Game gg = new Game();
		gg.run();
		
	}

	public void run() {
		System.out.println("**Bear�� Fish�Ա� ������ �����մϴ�.**");
		update();
		draw();
		while(doesEnd() != false) {
			clear();
			for(int i = 0;i<g.length;i++) g[i].move();
			update();
			draw();
		}
	}
	public void clear() {
		for(int i =0;i<g.length;i++)
			map[g[i].getX()][g[i].getY()] = '-';
	}
	public boolean doesEnd() {
		if(g[0].collide(g[1])) return false;
		return true;
	}
	public void draw() {
		for(int i=0;i<MAX_Y;i++) {
			for(int j =0;j<MAX_X;j++)
			{	System.out.print(map[j][i]);}
			System.out.println();
		}
		
	}

	public void update() {
		for(int i =0;i<g.length;i++)
			map[g[i].getX()][g[i].getY()] = g[i].getShape();
	}

}
