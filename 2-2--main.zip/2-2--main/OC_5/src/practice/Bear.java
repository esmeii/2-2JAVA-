package practice;

import java.util.Scanner;

public class Bear extends GameObject{
	
	public Bear(int x,int y, int distance) {
		super(x,y,distance);
	}

	@Override
	protected void move() {
		//Ű�� ���� �� ĭ�� �����δ�.
		Scanner s = new Scanner(System.in);
		System.out.print("����(a), �Ʒ�(s), ��(d), ������(f) >>");
		char ch = s.next().charAt(0);
		switch(ch) {
		case 'a': 
			if(x<0) x=0;
			else this.x-=1; break;
		case 's': 
			if(y>=10) this.y = 0;
			else this.y+=1; break;
		case 'd':
			if(y<0) y = 0;
			else this.y-=1; break;
		case 'f': 
			if(x>=20) x=0;
			else this.x+=1; break;
		default: System.out.println("wrong input");
		}
	}

	@Override
	protected char getShape() {
		return 'B';
	}
	

}
