package practice;

public class Fish extends GameObject{

	public Fish(int x,int y, int distance) {
		super(x,y,distance);
	}

	@Override
	protected void move() {
		//5���� �� ���� ���ڸ��� �ִ�.
		int n = (int)(Math.random()*5);
		switch(n) {
		case 1: x-=distance; y-=distance;
		 if(x<0) x=0;
		 if(y<0) y=0;
		case 2: x+=distance; y+=distance;
		if(x>20) x=20-1; 
		if(y>10) y=10-1;	
		}
	}

	@Override
	protected char getShape() {
		// TODO Auto-generated method stub
		return '@';
	}

}
