package practice;

public abstract class GameObject {
	protected int distance;
	protected int x,y;
	public GameObject(int x, int y, int distance) {
		this.x=x; this.y = y; this.distance=distance;
	}
	public int getX() {return x;}
	public int getY() {return y;}
	public boolean collide(GameObject obj) {
		if(this.x == obj.getX() && this.y == obj.getY())
			return true;
		else
			return false;
	}
	protected abstract void move();
	protected abstract char getShape();
}
