import java.util.Scanner;

public class Bear extends GameObject{
	private Scanner s;
	public Bear(int startX, int startY, int distance) {
		super(startX, startY, distance);
		System.out.println("BEAR");
		s = new Scanner(System.in);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.print("����(a), �Ʒ�(s), ��(d), ������(f)>>");
		String bearControl = s.nextLine();
		//char c = s.next().charAt(0); �̷��� ������
		if(bearControl.equals("a")) {
			setX(this.getX()-1);
			if(x <0) setX(x +=1);
		}
		else if(bearControl.equals("s")) {
			setY(this.getY()+1);
			if(y>=Game_1.MAX_Y) setY(y=Game_1.MAX_Y+1);
		}
		else if(bearControl.equals("d")) {
			setY(this.getY()-1);
			if(y<0) setY(y+=1);
		}
		else if(bearControl.equals("f")) {
			setX(this.getX()+1);
			if(x >= Game_1.MAX_X) 
				setX(x = Game_1.MAX_X -1);
		}
		else System.out.println("wrong input!");
	}

	@Override
	protected char getShape() {
		// TODO Auto-generated method stub
		return 'B';
	}
	public boolean collide(Fish f) {
		if(this.x == f.getX() && this.y == f.getY()) {
			return true;
		}
		else return false;
	}
	public void setX(int x) {
		this.x = x;
	}
	public void setY(int y) {
		this.y = y;
		
	}
}
