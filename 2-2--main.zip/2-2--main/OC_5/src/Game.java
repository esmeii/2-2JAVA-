//
//public class Game {
//	
//	private int x = (int)(Math.random()*20);
//	private int y = (int)(Math.random()*10);
//	Bear b= new Bear(0,0,1); //bear ��ü
//	Fish f = new Fish(x,y,1); //fish ��ü
//	
//	public Game() {
//	}//constructor
//	
//	public void run() {//run method
//		System.out.println("** Bear �� Fish �Ա� ������ �����մϴ�.**");
//		while(true) {
//		for(int i =0;i<10;i++) {
//			for(int j = 0;j<20;j++) {
//				if(b.getX() == j && b.getY() == i) {
//					System.out.print(b.getShape());
//					}
//				else if(f.getX() == j && f.getY() == i){
//					System.out.print(f.getShape());
//				}
//				else System.out.print("-");
//		
//			}System.out.println();
//		}
//		b.move();
//		f.move();
//		if(b.collide(f)==true) {
//			break;
//		}
//		}//while end
//		
//		System.out.println("Game Over!!!!!!!!!!!!");
//	}//run method end
//	public static void main(String[] args) {
//		Game g = new Game(); //���� ��ü
//		g.run(); //���� ����
//	}
//}
//	
//
