
public class Game_1 {
	public static final int MAX_X = 20;
	public static final int MAX_Y = 10;
	private char map [][] = new char[MAX_Y][MAX_X];
	private GameObject [] m = new GameObject[2];
	int state; // 0,1,2
	private int x = (int)(Math.random()*20);
	private int y = (int)(Math.random()*10);
	
	public Game_1() { //constructor	
		for(int i =0;i<MAX_Y;i++)
			for(int j =0;j<MAX_X;j++)
				map[i][j] = '-';
		m[0] = new Bear(0,0,1);
		m[1] = new Fish(x,y,1);
		state = 0;// 0==gaming
	}
	public void run() {
		System.out.println("** Bear �� Fish �Ա� ������ �����մϴ�.**");
		
		update();//�ʱ� �� ����
		draw();//�ʱ� ���� ������
		while(!doesEnd()){
			clear(); //���� �� ����
			for(int i =0;i<m.length;i++)
				m[i].move();
			update();
			draw();
		}
		System.out.println("Game ��");
	}
	private boolean doesEnd() {
		if(m[0].collide(m[1])) {
			return true;
		}
		return false;
	}
	private void clear() {
		for(int i =0;i<m.length;i++) {
			map[m[i].getY()][m[i].getX()]='-';
		}
	}
	private void draw() {
		// TODO Auto-generated method stub
		System.out.println();
		for(int i =0;i<MAX_Y;i++) {
			for(int j=0;j<MAX_X;j++){
			System.out.print(map[i][j]);
		}
		System.out.println();
		
		}
	}
	private void update() {
		for(int i =m.length-1;i>=0;i--)
			map[m[i].getY()][m[i].getX()]=m[i].getShape();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Game_1 g = new Game_1();
		g.run();
	}

}
