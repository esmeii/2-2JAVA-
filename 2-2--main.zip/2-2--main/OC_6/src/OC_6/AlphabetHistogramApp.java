package OC_6;
import java.util.Scanner;

public class AlphabetHistogramApp {
	private int histoData [] = new int[26];
	private int histoData1 [] = new int[26];
	public AlphabetHistogramApp() {
		for(int i =0;i<histoData.length;i++)
			histoData [i]=0; //�ʱ�ȭ
	}
	public void run() {
		String s = readString();
		makeHistogram(s);
		drawHistogram();
	}
	public void drawHistogram() {
		System.out.println("������׷� �׸���");
		for(int i =0;i<histoData.length;i++) {
			System.out.print((char)('A'+i)+" ");
			
			for(int j =0;j<histoData[i];j++) {
				System.out.print('-');
			}
		}
			for(int i =0;i<histoData1.length;i++) {
				System.out.print((char)('a'+i)+" ");
				
				for(int j =0;j<histoData1[i];j++) {
					System.out.print('-');
				}
			System.out.println();
		}
	}
	public String readString() {
		StringBuffer sb = new StringBuffer();
		Scanner scan = new Scanner(System.in);
		System.out.println("�����ؽ�Ʈ�� �Է��ϰ� ;�� �Է��ϼ���");
		while(true) {
			String line = scan.nextLine();
			if(line.equals(";")) break;
			sb.append(line);//BUFFER�� ����
		}
		scan.close();
		return sb.toString();
	}
	//���ڵ��� �빮�ڷ� ���� ����
	public void makeHistogram(String st) {
		String s= st.toString();
		//s= s.toUpperCase(); //�빮�ڷ� ����
		//System.out.println(s);
		//�Էµ� ��� ���ڸ� ���� histoData�� ����
		for(int i =0;i<s.length();i++) {
			char c= s.charAt(i);
			if(c>='A' && c<= 'Z') {
				int index = c -'A';//0~25
				histoData[index]++;
			}
			else if(c>='a' && c<='z') {
				int index1 = c - 'a';
				histoData[index1]++;
			}
		}
	}
	public static void main(String[] args) {
		AlphabetHistogramApp ap = new AlphabetHistogramApp();
		ap.run();
		System.out.println("�����մϴ�.");
	}


}
