package _6_7;

public class StringEx {

	public static void main(String[] args) {
		//46������
		String java= "Java";
		String cpp = "C++";
		int res = java.compareTo(cpp);
		if(res == 0)
		System.out.println("the same");
		else if(res <0)
		System.out.println(java + " < " + cpp);
		else
		System.out.println(java + " > " + cpp);
System.out.println();
//49page
String a1 = " abcd def ";
String b1 = " xyz\t";
System.out.println(a1.trim()); 
System.out.println(b1.trim());
System.out.println();
		String a = new String(" C#");
		String b =new String(",C++");
		
		System.out.println(a+"'s length:"+a.length());
		System.out.println(a.contains("#"));
		
		a= a.concat(b);//�̾���̱�
		System.out.println(a);
		
		a = a.trim();//���� ����
		System.out.println(a);
		
		a = a.replace("C#", "Java");//��ü
		System.out.println(a);
		
		String s[] = a.split(",");//�������� �и�
		for(int i = 0;i<s.length;i++) {
			System.out.println("�и��� ���ڿ�:"+i+":"+s[i]);
		}
		
		a= a.substring(5);
		System.out.println(a);
		
		char c = a.charAt(2);
		System.out.println(c);
		
		
		System.out.println(a.toString());
	}

}
