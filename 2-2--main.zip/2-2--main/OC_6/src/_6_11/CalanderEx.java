package _6_11;

public class CalanderEx {
	public static void printCalendar() {
		
	}
	public static void main(String[] args) {
		
	}

}
