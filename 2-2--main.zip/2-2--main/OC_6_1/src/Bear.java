import java.util.Scanner;

public class Bear extends GameObject{

	public Bear(int x, int y, int distance) {
		super(x,y,distance);
	}

	@Override
	protected void move() {
		Scanner s = new Scanner(System.in);
		char moveKey = s.next().charAt(0);
		switch(moveKey) {
		case 'a': x--; 
				if(x<0) x++; break;
		case 's': y--;
				if(y<0) y++; break;
		case 'd': y++;
				if(y>GameObjectApp.MAX_HEIGHT) y--;
				break;
		case 'f': x++;
				if(x>GameObjectApp.MAX_LENGTH) x--;
				break;
		}
		
	}

	@Override
	protected char getShape() {
		// TODO Auto-generated method stub
		return 'B';
	}

}
