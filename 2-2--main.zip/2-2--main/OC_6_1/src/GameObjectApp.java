
public class GameObjectApp {
	GameObject[] p;
	public final static int MAX_LENGTH = 20;
	public final static int MAX_HEIGHT = 10;
	char [][] m = new char[MAX_HEIGHT][MAX_LENGTH];
	public GameObjectApp() {
		for(int i = 0;i<MAX_HEIGHT;i++) {
			for(int j = 0;j<MAX_LENGTH;j++)
				m[i][j] = '-';
		}
		p = new GameObject[2];
		p[0] = new Bear(0,0,1);
		p[1] = new Fish(5,8,1);
	}
	public void run() {
		System.out.println("������ �����մϴ�.");
		
		update();
		draw();
		while(true) {
			clean(); 
			for(int i = 0;i<p.length;i++)
				p[i].move();
			update(); //�����ι� ��ġ
			draw();
			if(check()) break;
			else continue;
		}
	}
	public void clean() {
		for(int i = 0;i<MAX_HEIGHT;i++) {
			for(int j = 0;j<MAX_LENGTH;j++)
				m[i][j] = '-';
		}
	}
	public boolean check() {
		if(p[0].collide(p[1])) return true;
		else return false;
	}
	public void update() {
		for(int i = p.length-1;i>=0;i--) {
			m[p[i].getX()][p[i].getY()]= p[i].getShape();
		}
	}
	public void draw() {
		for(int i = 0;i<MAX_HEIGHT;i++) {
			for(int j = 0;j<MAX_LENGTH;j++)
				System.out.print(m[i][j]);
			System.out.println();
		}
		System.out.println();
	}
	public static void main(String[] args) {
		GameObjectApp a = new GameObjectApp();
		a.run();
	}

}
