
public class Fish extends GameObject{

	public Fish(int x,int y, int distance) {
		super(x,y,distance);
	}

	@Override
	protected void move() {
		int whereMove;
		int possibility = (int)Math.random()*5;
		if(possibility == 0 || possibility == 1) {
			whereMove = (int)Math.random()*4;
			switch(whereMove) {
			case 0: x--; 
			if(x<0) x++; break;
			case 1:y--;
			if(y<0) y++; break;
			case 2:y++;
			if(y>GameObjectApp.MAX_HEIGHT) y--;
			break;
			case 3:x++;
			if(x>GameObjectApp.MAX_LENGTH) x--;
			break;
			}
		}
	}

	@Override
	protected char getShape() {
		
		return '@';
	}

}
