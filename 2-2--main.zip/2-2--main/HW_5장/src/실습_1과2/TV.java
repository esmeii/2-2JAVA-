package �ǽ�_1��2;

class TV {
	private int size;
	public TV(int size) {this.size=size;}
	protected int getSize() { return size; }
}
