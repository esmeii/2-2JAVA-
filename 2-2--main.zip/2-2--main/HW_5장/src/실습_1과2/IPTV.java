package �ǽ�_1��2;

public class IPTV extends ColorTV{
	private String add;
	public IPTV (int size, int color, String add) {
		super(size,color);
		this.add = add;
	}
	public void printproperty() {
		System.out.println(add+"�ּ��� ");
		super.printProperty();
		
	}
}
