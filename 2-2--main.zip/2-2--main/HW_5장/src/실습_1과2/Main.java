package �ǽ�_1��2;

public class Main {
	public static void main(String [] args) {
		ColorTV myTV = new ColorTV(32,1024);
		myTV.printProperty();
		
		IPTV iptv = new IPTV(32,1024,"1929");
		iptv.printproperty();
		
	}
}
