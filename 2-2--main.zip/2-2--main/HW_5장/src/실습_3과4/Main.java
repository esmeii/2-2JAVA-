package �ǽ�_3��4;

public class Main {

	public static void main(String[] args) {
		Won2Dollar toDollar = new Won2Dollar(1200);
		toDollar.run();
		
		Km2Mile toMile = new Km2Mile(1.6);
		toMile.run();

	}

}
