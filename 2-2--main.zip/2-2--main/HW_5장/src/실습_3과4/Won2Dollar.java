package �ǽ�_3��4;

public class Won2Dollar extends Converter{
	private int ratio;
	public Won2Dollar(int ratio) {
		this.ratio = ratio;
	}

	@Override
	protected double convert(double src) {return src/ratio;}

	@Override
	protected String getSrcString() {
		return "��";
	}

	@Override
	protected String getDestString() {
		// TODO Auto-generated method stub
		return "�޷�";
	}

}
