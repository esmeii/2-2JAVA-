package N12��;
public class Circle extends Shape{
	public Circle() {}
	@Override
	public void draw() {System.out.println("Circle");}

}
