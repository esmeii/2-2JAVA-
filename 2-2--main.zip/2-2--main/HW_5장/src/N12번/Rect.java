package N12��;
class Rect extends Shape{
	public Rect() {}
	public void draw() {System.out.println("Rect");}
}
