package N12��;
public class Line extends Shape{
	public Line() {	}
	@Override
	public void draw() {
		System.out.println("Line");
	}
}
