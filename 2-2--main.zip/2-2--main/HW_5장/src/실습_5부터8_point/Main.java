package �ǽ�_5����8_point;

public class Main {

	public static void main(String[] args) {
		ColorPoint cp = new ColorPoint(5,5,"YELLOW");
		cp.setColor("RED");
		cp.setXY(10, 20);
		System.out.println(cp.toString());
		
		ColorPoint zeroPoint = new ColorPoint();
		zeroPoint.setXY(5, 5);
		System.out.println(zeroPoint.toString());
		
		ColorPoint ccp = new ColorPoint(10,10);
		ccp.setColor("RED");
		System.out.println(ccp.toString());
		
		Point3D p = new Point3D(1,2,3);
		p.moveUp();
		p.move(100, 200, 300);
		System.out.println(p.toString());
		}

}
