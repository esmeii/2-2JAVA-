package �ǽ�_5����8_point;

public class PositivePoint extends Point{

	public PositivePoint() {
		super(10,10);
	}
	public PositivePoint(int x,int y) {
		super(x,y);
		this.move(x, y);
	}
	public String toString() {
		return "("+getX()+","+getY()+")�� ��";
	}
	public void move(int x, int y){
		if(x<0 || y<0) {
			return;
		}
		else super.move(x, y);
	}
	

}
