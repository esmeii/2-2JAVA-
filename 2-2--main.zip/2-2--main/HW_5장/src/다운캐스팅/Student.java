package �ٿ�ĳ����;

public class Student extends Person{
	String grade;
	String department;
	
	public Student(String name) {
		super(name);
	}
}
