package �ǽ�_13��_����;

public class Main {

	public static void main(String[] args) {
		Shape [] list = new Shape[3];
		list[0] = new Circle(10);
		list[1] = new Rect(10,20);
		list[2] = new Circle(18);
		
		for(int i = 0;i<list.length;i++) list[i].redraw();
		for(int i =0;i<list.length;i++) System.out.println(list[i].getArea());
	}

}
