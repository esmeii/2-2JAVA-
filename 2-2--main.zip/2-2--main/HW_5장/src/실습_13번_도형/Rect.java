package �ǽ�_13��_����;

public class Rect implements Shape {
	private int wid,len;
	public Rect(int wid, int len) {
		this.len = len; this.wid = wid;
	}

	@Override
	public void draw() {
		System.out.println(len+"*"+wid+"�� �簢��");
	}

	@Override
	public double getArea() {
		return len*wid;
	}

}
