package �ǽ�_9��;

public class StringStack implements Stack {
		int tos;
		String [] elements;
		int size;
		
	public StringStack(int s) {
		this.size = s;
		elements = new String[s];
		tos= 0;
	}

	public boolean push(String s) {//string ����
		if(size<= 0) {
			System.out.println("���� push�Ұ�");
			return false;
		}
		elements[tos] = s;
		tos++;
		size--;
		return true;
	}

	public String pop() {
		return elements[--tos];
	}

	@Override
	public int length() {
		
		return tos;
	}

	@Override
	public int capacity() {

		return size;
	}

}
