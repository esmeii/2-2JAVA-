package �ǽ�_9��;

import java.util.Scanner;

public class StackApp {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int s;
		System.out.println("�� ����>>");
		s = scan.nextInt();
		StringStack ss = new StringStack(s);
		while(true) {
			System.out.print("���ڿ� �Է�>> ");
			String str = scan.next();
			if(str.equals("�׸�")) break;
			boolean b= ss.push(str);
			if(b==false )continue;
		}
		
		for(int i =0;i<s;i++) {
			System.out.print(ss.pop()+" ");
		}
	}

}
