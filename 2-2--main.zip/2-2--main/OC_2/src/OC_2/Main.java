package OC_2;

import java.util.Scanner;

class RGBGame{
	Person[] p;
	private String[] cmp;
	public RGBGame() {
		Person[] p = new Person[2];
		for(int i = 0;i<p.length;i++) {
			p[i] = new Person(i);
			
	}
		cmp = new String[2];
	}
	public void run() {
		Scanner s = new Scanner(System.in);
		System.out.println("���������� �����Դϴ�. �Է��ϼ���");
		for(int i = 0;i<2;i++) {
			System.out.print(p[i].getName()+">>");
			cmp[i] = s.nextLine();
		}
		if(cmp[0].equals(cmp[1])) System.out.println("���");
	}
}
class Person{
	private String name;
	public Person(int i) {
		this.name = "ö��"+i;
	}
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	public Person(String name) {
		this.name=name;
	}
}
class Girl extends Person{

	public Girl(int i) {
		super(i);
	}
}
class Boy extends Person{

	public Boy(int i) {
		super(i);
	}
}
public class Main {

	public static void main(String[] args) {
		RGBGame g = new RGBGame();
		g.run();
	}

}
