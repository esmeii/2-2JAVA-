package �ǽ�_7��_StringŬ����;

import java.util.Scanner;
import java.util.StringTokenizer;

class StringEX{
	public void run() {
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.print(">>");
		String line = sc.nextLine();
		if(line.equals("�׸�")) break;
		StringTokenizer st = new StringTokenizer(line," ");
		int n = st.countTokens();
		System.out.println("���� ������ "+n);
	}
	}
}
class StringEX2{
	public void run() {
	Scanner scc = new Scanner(System.in);
	while(true) {
		System.out.print(">>");
		String line = scc.nextLine();
		if(line.equals("�׸�")) break;
		String s[] = line.split(" ");		
		int n = s.length;
		System.out.println("���� ������ "+n);
		}
	}
}
public class Main {

	public static void main(String[] args) {
//		StringEX strEX= new StringEX();
//		strEX.run();
		StringEX2 strEX = new StringEX2();
		strEX.run();
	}

}
