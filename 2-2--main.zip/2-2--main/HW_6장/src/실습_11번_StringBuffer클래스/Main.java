package �ǽ�_11��_StringBufferŬ����;

import java.util.*;

public class Main {
	public void run() {
		Scanner s  = new Scanner(System.in);
		System.out.print(">> ");
		String line = s.nextLine();
		StringBuffer sb = new StringBuffer(line); //���� ����
//		
//		String[] input = line.split(" ");
//		while(true) {
//			System.out.print("����:");
//			String command = s.next();
//			if(command.equals("�׸�")) break;
//			String[] st = command.split("!");
//			if(st[0] == "") System.out.println("�߸��� �����Դϴ�.");
//			for(int i =0;i<input.length;i++) {
//				if(st[0].equals(input[i])) {
//					line = line.replace(input[i], st[1]);
//				}
//			}
//			System.out.println(line);
//		}
		while(true) {
			System.out.print("����: ");
			String cmd = s.nextLine();
			if(cmd.equals("�׸�")) break;
			String[] tokens = cmd.split("!");
			if(tokens.length != 2) {
				System.out.println("�߸��� �����Դϴ�.");
			}
			else {
				if(tokens[0].length()==0 || tokens[1].length()==0) {
					System.out.println("�߸��� �����Դϴ�.");
					continue;
				}
				int index = sb.indexOf(tokens[0]);
				if(index == -1) {
					System.out.println("ã�� �� �����ϴ�.");
					continue;
				}
				sb.replace(index,index+tokens[0].length(), tokens[1]);
				System.out.println(sb);
			}
		}
	}

	public static void main(String[] args) {
		Main m = new Main();
		m.run();
	}

}
