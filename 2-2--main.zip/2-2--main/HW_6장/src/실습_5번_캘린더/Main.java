package �ǽ�_5��_Ķ����;

import java.util.Calendar;

public class Main {

	public static void main(String[] args) {
		Calendar cd = Calendar.getInstance();
		int hour = cd.get(Calendar.HOUR_OF_DAY);
		int min = cd.get(Calendar.MINUTE);
		System.out.println("���� �ð���"+hour+"��"+min+"���Դϴ�.");
		if(hour >4 && hour <12) System.out.println("Good Morning");
		else if(hour<18) System.out.println("Good Afternoon");
		else if(hour<22) System.out.println("Good Evening");
		else System.out.println("Good Night");
		
	}

}
