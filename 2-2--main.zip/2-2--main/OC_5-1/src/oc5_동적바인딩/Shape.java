package oc5_�������ε�;

public class Shape {
	protected String name;
	public void paint() {
		draw();
	}
	public void draw() {
		System.out.println("Shape");
	}
	
	

}
public class Circle extends Shape{
	public void draw() {
		System.out.println("Circle");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape b = new Circle();
		b.paint();

	}
}