
public interface Stack {
	int length();
	int capacity();
	String pop();
	
}
